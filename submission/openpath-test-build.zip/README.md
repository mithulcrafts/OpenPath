# OpenPath local test build

A precompiled local build from https://github.com/mithulcrafts/OpenPath. Requires Node.js 24 and npm. Extract the ZIP into a writable folder, then open a terminal in that folder.

## Capability workspace

Enter a product URL to inspect up to four public pages. OpenPath groups captured links and page evidence into inferred product capabilities. Choose a capability and an HTML reader, browser agent or API client perspective. The workspace shows captured pages, unknown connections and proposed changes separately.

Use **Understand** to inspect the route, **Plan changes** to review scoped findings, and **Verify** to run a bounded browser task with an independent outcome check. Export an implementation brief for the selected capability and agent profile. Saved inspections, evidence, recorded model calls and before/after comparisons remain available.

Capability names are deterministic hypotheses from captured content, not proof of completed tasks. OpenPath does not automatically edit the inspected website. NVIDIA Nemotron reviews observed findings and chooses browser actions when live inference is configured; Nebius Token Factory serves the model through its managed API.

## Install and run

1. Run `npm ci --omit=dev` to install the locked runtime dependencies.
2. Run `npm run browser:install` to install Chromium into `.cache/ms-playwright`.
3. Copy `.env.example` to `.env` (`Copy-Item .env.example .env` in PowerShell; `cp .env.example .env` on macOS/Linux).
4. Run `npm start` and open http://127.0.0.1:4173.

Installation needs internet access. Linux may need Chromium system dependencies: run `npm run browser:install -- --with-deps` with the permissions requested by your package manager. No compilation is needed; source-development commands are not part of this build.

## Credit-free local demo

The supplied example has `OPENPATH_AI_ENABLED=false`, `OPENPATH_DEMO_MODE=true`, and a blank Nebius key. Keep those values for the local scripted demo, and clear any existing `OPENPATH_AI_ENABLED` environment override. The server reads process environment variables before `.env`.

Choose the built-in broken storefront, inspect it, and run the standard blue, size-M cart task. Compare with the built-in fixed storefront. These controlled demo pages and the scripted trial work locally after installation; they make no model calls. The scripted trial is a deterministic demonstration, not live NVIDIA inference. Inspecting an external website requires network access. Live AI mode requires your own Nebius credentials and explicit configuration.

The app binds to loopback by default. Stop it with Ctrl+C. New local results are stored in `data/`; no prior results are supplied. If port 4173 is busy, change PORT in `.env` before starting.

## Package contents

- `dist/client`: compiled interface.
- `dist/server`: compiled server.
- `dist/shared` and `dist/demo-site`: shared runtime types and controlled demo pages used by the server.
- `package.json`, `package-lock.json`, `scripts/production.mjs`, and `scripts/install-browser.mjs`: locked installation and production startup.
- `.env.example` and `LICENSE`: safe configuration template and license.

No credentials, node_modules, browser cache, prior reports, recorded evidence, private research, or data are included. Dependencies and Chromium are installed on your machine to keep the download small.
